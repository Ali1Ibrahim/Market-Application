import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.security.auth.Refreshable;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AddSupplier extends JFrame {

	private JPanel contentPane;
	private JTextField tx_code;
	private JTextField tx_name;
	private JTextField tx_address;
	private JTextField tx_contact;
	private JTextField tx_product_type;
	private JTextField tx_website;
	private JTextField tx_email;
	private JTable table;
	private JTextField txtID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddSupplier frame = new AddSupplier();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddSupplier() {
		setUndecorated(true);
		setResizable(false);
		setTitle("Suppliers");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 875, 601);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCode = new JLabel("Code");
		lblCode.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCode.setBounds(10, 124, 107, 14);
		contentPane.add(lblCode);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblName.setBounds(10, 167, 107, 14);
		contentPane.add(lblName);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddress.setBounds(10, 209, 107, 14);
		contentPane.add(lblAddress);
		
		JLabel lblContact = new JLabel("Contact");
		lblContact.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblContact.setBounds(10, 258, 107, 14);
		contentPane.add(lblContact);
		
		JLabel lblProductType = new JLabel("Product Type");
		lblProductType.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblProductType.setBounds(10, 302, 107, 14);
		contentPane.add(lblProductType);
		
		JLabel lblWebsite = new JLabel("WebSite");
		lblWebsite.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblWebsite.setBounds(10, 346, 107, 14);
		contentPane.add(lblWebsite);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblEmail.setBounds(10, 395, 107, 14);
		contentPane.add(lblEmail);
		
		tx_code = new JTextField();
		tx_code.setBounds(155, 120, 192, 23);
		contentPane.add(tx_code);
		tx_code.setColumns(10);
		
		tx_name = new JTextField();
		tx_name.setBounds(155, 164, 190, 23);
		contentPane.add(tx_name);
		tx_name.setColumns(10);
		
		tx_address = new JTextField();
		tx_address.setBounds(155, 203, 192, 23);
		contentPane.add(tx_address);
		tx_address.setColumns(10);
		
		tx_contact = new JTextField();
		tx_contact.setBounds(155, 250, 192, 23);
		contentPane.add(tx_contact);
		tx_contact.setColumns(10);
		
		tx_product_type = new JTextField();
		tx_product_type.setBounds(155, 296, 192, 23);
		contentPane.add(tx_product_type);
		tx_product_type.setColumns(10);
		
		tx_website = new JTextField();
		tx_website.setBounds(155, 340, 192, 23);
		contentPane.add(tx_website);
		tx_website.setColumns(10);
		
		tx_email = new JTextField();
		tx_email.setBounds(155, 389, 192, 23);
		contentPane.add(tx_email);
		tx_email.setColumns(10);
		
		JButton btn_add_sub = new JButton("ADD Supplire");
		btn_add_sub.setFont(new Font("Tahoma", Font.BOLD, 15));
		btn_add_sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String contact = tx_contact.getText();
			    String product_type = tx_product_type.getText(); 
			    String website = tx_website.getText();
			    String email = tx_email.getText(); 
 			     try {
			            Connection con = DBconnect.getConnection();
			           
			            String query = "INSERT INTO `store`.`suppliers` (`Code`, `Name`, `Address`, `Contact`, `Product_type`, `Website`, `Email`) VALUES (?, ?, ?, ?, ?, ?, ?);";
			            java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query) ;
                        ps.setString(1, id);
                        ps.setString(2, name);
                        ps.setString(3, address);
                        ps.setString(4, contact);
                        ps.setString(5, product_type);
                        ps.setString(6, website);
                        ps.setString(7, email);
                        ps.executeUpdate();
			             JOptionPane.showMessageDialog(null, "Successful");
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

			           e.printStackTrace();
			        }
 			    Connection con10 = null ; 
				PreparedStatement ps5 = null ; 
				ResultSet rs5= null ; 

				try {
					con10=DBconnect.getConnection() ; 
					String query = "Select * from suppliers" ; 
					ps5 = (PreparedStatement) con10.prepareStatement(query);
					rs5=ps5.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
					
				} catch (SQLException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
			}
		});
		btn_add_sub.setBounds(173, 449, 149, 23);
		contentPane.add(btn_add_sub);
		
		JLabel lblSupplires = new JLabel("Supplires");
		lblSupplires.setForeground(Color.BLUE);
		lblSupplires.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblSupplires.setBounds(381, 23, 102, 32);
		contentPane.add(lblSupplires);
		
		JButton btnDisplayTable = new JButton("Display Table");
		btnDisplayTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Connection con2 = null ; 
				PreparedStatement ps2 = null ; 
				ResultSet rs2 = null ; 
				try {
					con2=DBconnect.getConnection() ; 
					String query = "Select * from suppliers" ; 
					ps2 = (PreparedStatement) con2.prepareStatement(query);
					rs2=ps2.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs2)) ;
					
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, "Error");
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
			}
		});
		btnDisplayTable.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDisplayTable.setBounds(173, 483, 149, 23);
		contentPane.add(btnDisplayTable);
		
		JButton button = new JButton("Modify - Edit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String contact = tx_contact.getText();
			    String product_type = tx_product_type.getText(); 
			    String website = tx_website.getText();
			    String email = tx_email.getText(); 



				     try {
				            Connection con = DBconnect.getConnection(); 
				            
				          String query = "UPDATE `store`.`suppliers` SET `Name` =?, `Address` = ?, `Contact` = ?, `Product_type` = ?, `Website` = ?, `Email` = ? WHERE (`Code` = ?);";



				             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
				            ps=con.prepareStatement(query); 
				            ps.setString(1, name);
				            ps.setString(2, address);
				            ps.setString(3, contact);
				            ps.setString(4, product_type);
				            ps.setString(5, website);
				            ps.setString(6,email);
				      
				            ps.setString(7, id);


				            ps.executeUpdate() ;
							Refreshable();


				             JOptionPane.showMessageDialog(null, "Successful");
				        } catch (Exception ee) {
				             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

				           ee.printStackTrace();
				        }
				
						Refreshable();
						Connection con10 = null ; 
						PreparedStatement ps5 = null ; 
						ResultSet rs5= null ; 

						try {
							con10=DBconnect.getConnection() ; 
							String query = "Select * from suppliers" ; 
							ps5 = (PreparedStatement) con10.prepareStatement(query);
							rs5=ps5.executeQuery() ;
						   
							table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
							
						} catch (SQLException ee) {
							// TODO Auto-generated catch block
							ee.printStackTrace();
						} 
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 15));
		button.setBounds(173, 517, 149, 23);
		contentPane.add(button);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(354, 120, 521, 289);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = table.getSelectedRow();
				 int id = Integer.parseInt(table.getValueAt(i, 0).toString());
				 String name = table.getValueAt(i, 1).toString();
				 String address = table.getValueAt(i, 2).toString();
				 String contact = table.getValueAt(i, 3).toString();

				 String product_type = table.getValueAt(i, 4).toString();

				 String website = table.getValueAt(i, 5).toString();

            
				 String email = table.getValueAt(i, 6).toString();
 			 



				 tx_code.setText(""+id);
				 tx_name.setText(name);
				 tx_address.setText(address);
				 tx_contact.setText(contact);

				 tx_product_type.setText(product_type);
				 tx_website.setText(website);


				 tx_email.setText(email);
		 
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
			}
		});
		label.setIcon(new ImageIcon(AddSupplier.class.getResource("/soursess/stand-by.png")));
		label.setBounds(842, 11, 23, 25);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				home_page hp = new home_page();
				hp.setVisible(true);
				setVisible(false);
			}
		});
		label_1.setIcon(new ImageIcon(AddSupplier.class.getResource("/soursess/reply (2).png")));
		label_1.setBounds(809, 11, 23, 25);
		contentPane.add(label_1);
		
		txtID = new JTextField();
		txtID.setToolTipText("ID");
		txtID.setText(" ");
		txtID.setColumns(10);
		txtID.setBounds(694, 94, 105, 25);
		contentPane.add(txtID);
		
		JButton button_1 = new JButton("Delete");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	int message = JOptionPane.showConfirmDialog(null, "Do you Want Delete ?", "Delete", JOptionPane.YES_NO_OPTION);
				

		        if (message == 0) {

		            try {
		            	Connection con2 = null;
		            	PreparedStatement pst2 = null;
		            	con2 = DBconnect.getConnection();
		            	
		                String sql = " delete from suppliers where Code = ?";
                        pst2 = (PreparedStatement) con2.prepareStatement(sql);
                        
		               
		                pst2.setString(1, txtID.getText());

		                pst2.execute();
		                JOptionPane.showMessageDialog(null, "Deleted Successfully");

		            } catch (Exception ee) {
		                JOptionPane.showMessageDialog(null, e);
		            }
		    		Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5 = null ; 
					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from suppliers" ; 
						ps5 = (PreparedStatement) con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					} 
			}
			}
		});
		button_1.setBounds(805, 95, 70, 26);
		contentPane.add(button_1);
	}

	protected void Refreshable() {
		// TODO Auto-generated method stub
		
	}
}
