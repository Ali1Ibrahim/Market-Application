import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.naming.spi.DirStateFactory.Result;
import javax.security.auth.Refreshable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;

public class AddProduct extends JFrame {

	private JPanel contentPane;
	private JTextField tx_name;
	private JTextField tx_type;
	private JTextField tx_des;
	private JTextField tx_color;
	private JTextField tx_pcsinCTN;
	private JTextField tx_total_cartoon;
	private JTextField tx_total_pcs;
	private JTextField tx_price_pcs;
	private JTextField tx_cartoon_price;
	private JTextField tx_code;
	private JTable table;
	private JTextField txtID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddProduct frame = new AddProduct();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddProduct() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 941, 590);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tx_name = new JTextField();
		tx_name.setBounds(136, 139, 214, 27);
		contentPane.add(tx_name);
		tx_name.setColumns(10);
		
		tx_type = new JTextField();
		tx_type.setBounds(136, 177, 214, 27);
		contentPane.add(tx_type);
		tx_type.setColumns(10);
		
		tx_des = new JTextField();
		tx_des.setBounds(136, 215, 214, 27);
		contentPane.add(tx_des);
		tx_des.setColumns(10);
		
		tx_color = new JTextField();
		tx_color.setBounds(136, 253, 214, 27);
		contentPane.add(tx_color);
		tx_color.setColumns(10);
		
		tx_pcsinCTN = new JTextField();
		tx_pcsinCTN.setText("");
		tx_pcsinCTN.setBounds(136, 294, 214, 27);
		contentPane.add(tx_pcsinCTN);
		tx_pcsinCTN.setColumns(10);
		
		tx_total_cartoon = new JTextField();
		tx_total_cartoon.setText("");
		tx_total_cartoon.setBounds(136, 332, 214, 27);
		contentPane.add(tx_total_cartoon);
		tx_total_cartoon.setColumns(10);
		
		tx_total_pcs = new JTextField();
		tx_total_pcs.setBounds(136, 370, 214, 27);
		contentPane.add(tx_total_pcs);
		tx_total_pcs.setColumns(10);
		
		tx_price_pcs = new JTextField();
		tx_price_pcs.setBounds(136, 408, 214, 27);
		contentPane.add(tx_price_pcs);
		tx_price_pcs.setColumns(10);
		
		tx_cartoon_price = new JTextField();
		tx_cartoon_price.setBounds(136, 446, 214, 27);
		contentPane.add(tx_cartoon_price);
		tx_cartoon_price.setColumns(10);
		
		JButton btnAddProduct = new JButton("Add Product");
		btnAddProduct.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAddProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Code = tx_code.getText(); 
				String Name = tx_name.getText() ;
				String Type = tx_type.getText() ; 
				String Des = tx_des.getText() ; 
				String Color = tx_color.getText() ; 
				String CTN = tx_pcsinCTN.getText() ; 
				String total_cartoon = tx_total_cartoon.getText() ; 
				String total_pcs = tx_total_pcs.getText() ; 
				String cartoon_price = tx_cartoon_price.getText() ; 
				String price_pcs = tx_price_pcs.getText() ; 

               try {
		            Connection con = DBconnect.getConnection(); 
		           
				   String query = "INSERT INTO `store`.`products` (`Code`, `Name`, `Type`, `Descreption`, `Color`, `PcsinCTN`, `TotalCartoon`, `TotalPCS`, `CartoonPrice`, `psprice`) VALUES (?, ?, ?, ?, ?, ?,?, ?, ?,?);";
				   java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
		           ps=con.prepareStatement(query); 
			       ps.setString(1, Code);
			       ps.setString(2, Name);
			       ps.setString(3, Type);
			       ps.setString(4, Des);
			       ps.setString(5, Color);
			       ps.setString(6, CTN);
			       ps.setString(7, total_cartoon);
			       ps.setString(8, total_pcs);
			       ps.setString(9, cartoon_price);
			       ps.setString(10, price_pcs);
			       ps.executeUpdate() ; 
			       JOptionPane.showMessageDialog(null, "Successful");

               } catch (Exception e) {
		             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");
				e.printStackTrace();
			} 
           	Connection con10 = null ; 
			PreparedStatement ps5 = null ; 
			ResultSet rs5= null ; 

			try {
				con10=DBconnect.getConnection() ; 
				String query = "Select * from products" ; 
				ps5 = (PreparedStatement) con10.prepareStatement(query);
				rs5=ps5.executeQuery() ;
			   
				table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
				
			} catch (SQLException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
               
				
			}
		});
		btnAddProduct.setBounds(10, 499, 144, 27);
		contentPane.add(btnAddProduct);
		
		JLabel lblCode = new JLabel("Code");
		lblCode.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCode.setBounds(10, 99, 104, 14);
		contentPane.add(lblCode);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblName.setBounds(10, 143, 104, 14);
		contentPane.add(lblName);
		
		JLabel lblNewLabel = new JLabel("decscription");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 219, 104, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblType = new JLabel("Type");
		lblType.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblType.setBounds(10, 181, 104, 14);
		contentPane.add(lblType);
		
		JLabel lblColor = new JLabel("Color");
		lblColor.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblColor.setBounds(10, 257, 104, 14);
		contentPane.add(lblColor);
		
		JLabel lblCtn = new JLabel("CTN");
		lblCtn.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCtn.setBounds(10, 298, 104, 14);
		contentPane.add(lblCtn);
		
		JLabel lblTotalCartoon = new JLabel("Total cartoon");
		lblTotalCartoon.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTotalCartoon.setBounds(10, 336, 110, 14);
		contentPane.add(lblTotalCartoon);
		
		JLabel lblTotalPcs = new JLabel("Total PCS");
		lblTotalPcs.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTotalPcs.setBounds(10, 374, 104, 14);
		contentPane.add(lblTotalPcs);
		 
		JLabel lblPricePcs = new JLabel("Price PCS");
		lblPricePcs.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPricePcs.setBounds(10, 412, 104, 14);
		contentPane.add(lblPricePcs);
		
		JLabel lblCartoonPrice = new JLabel("Cartoon Price");
		lblCartoonPrice.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCartoonPrice.setBounds(10, 450, 110, 14);
		contentPane.add(lblCartoonPrice);
		
		JLabel lblProducts = new JLabel("Products");
		lblProducts.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblProducts.setBounds(234, 11, 86, 14);
		contentPane.add(lblProducts);
		
		JButton btnDisplayTable = new JButton("Display Table");
		btnDisplayTable.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDisplayTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 
 				Connection con2 = null ; 
				PreparedStatement ps2 = null ; 
				ResultSet rs2 = null ; 
				try {
					con2=DBconnect.getConnection() ; 
					String query = "Select * from products" ; 
					ps2 = (PreparedStatement) con2.prepareStatement(query);
					rs2=ps2.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs2)) ;
					
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, "Error");
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
			 
			}
		});
		btnDisplayTable.setBounds(176, 499, 144, 27);
		contentPane.add(btnDisplayTable);
		
		tx_code = new JTextField();
		tx_code.setColumns(10);
		tx_code.setBounds(136, 101, 214, 27);
		contentPane.add(tx_code);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(350, 99, 585, 374);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i = table.getSelectedRow();
				 int id = Integer.parseInt(table.getValueAt(i, 0).toString());
				 String name = table.getValueAt(i, 1).toString();
				 String type = table.getValueAt(i, 2).toString();
				 String des = table.getValueAt(i, 3).toString();

				 String color = table.getValueAt(i, 4).toString();

				 String pcsinCTN = table.getValueAt(i, 5).toString();

             
				 String total_cartoon = table.getValueAt(i, 6).toString();
				 String total_pcs = table.getValueAt(i, 7).toString();
				 String price_pcs = table.getValueAt(i, 8).toString();
				 String cartoon_price = table.getValueAt(i, 9).toString();



				 tx_code.setText(""+id);
				 tx_name.setText(name);
				 tx_type.setText(type);
				 tx_des.setText(des);

				 tx_color.setText(color);
				 tx_pcsinCTN.setText(pcsinCTN);


				 tx_total_cartoon.setText(total_cartoon);
				 tx_total_pcs.setText(total_pcs);
				 tx_price_pcs.setText(price_pcs);
				 tx_cartoon_price.setText(cartoon_price);

			}
		});
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
			}
		});
		label.setIcon(new ImageIcon(AddProduct.class.getResource("/soursess/stand-by.png")));
		label.setBounds(908, 14, 23, 25);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				home_page hp = new home_page();
				hp.setVisible(true);
				setVisible(false);
				
			}
		});
		label_1.setIcon(new ImageIcon(AddProduct.class.getResource("/soursess/reply (2).png")));
		label_1.setBounds(875, 14, 23, 25);
		contentPane.add(label_1);
		
		JButton button = new JButton("Modify - Edit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    String name = tx_name.getText();
			    String type = tx_type.getText(); 
			    String des = tx_des.getText();
			    String color = tx_color.getText(); 
			    String ctn = tx_pcsinCTN.getText();
			    String total_cartoon = tx_total_cartoon.getText(); 
			    String total_pcs = tx_total_pcs.getText();
			    String price_pcs = tx_price_pcs.getText();
			    String cartoon_price = tx_cartoon_price.getText();
				String id = tx_code.getText(); 



			     try {
			            Connection con = DBconnect.getConnection(); 
			            
			          String query = "UPDATE `store`.`products` SET `Name` = ?, `Type` = ?, `Descreption` =?, `Color` =?, `PcsinCTN` = ?, `TotalCartoon` = ?, `TotalPCS` = ?, `CartoonPrice` = ?, `psprice` = ? WHERE (`Code` = ?);";



			             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query); 
			            ps.setString(1, name);
			            ps.setString(2, type);
			            ps.setString(3, des);
			            ps.setString(4, color);
			            ps.setString(5, ctn);
			            ps.setString(6,total_cartoon);
			            ps.setString(7, total_pcs);
			            ps.setString(8, price_pcs);
			            ps.setString(9, cartoon_price);

			            ps.setString(10, id);


			            ps.executeUpdate() ;
						Refreshable();


			             JOptionPane.showMessageDialog(null, "Successful");
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

			           e.printStackTrace();
			        }
			
					Refreshable();
					Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5= null ; 

					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from products" ; 
						ps5 = (PreparedStatement) con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					} 

			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 15));
		button.setBounds(343, 499, 154, 27);
		contentPane.add(button);
		
		txtID = new JTextField();
		txtID.setToolTipText("ID");
		txtID.setText(" ");
		txtID.setColumns(10);
		txtID.setBounds(738, 73, 105, 25);
		contentPane.add(txtID);
		
		JButton button_1 = new JButton("Delete");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		int message = JOptionPane.showConfirmDialog(null, "Do you Want Delete ?", "Delete", JOptionPane.YES_NO_OPTION);
				

		        if (message == 0) {

		            try {
		            	Connection con2 = null;
		            	PreparedStatement pst2 = null;
		            	con2 = DBconnect.getConnection();
		            	
		                String sql = " delete from products where Code = ?";
                        pst2 = (PreparedStatement) con2.prepareStatement(sql);
                        
		               
		                pst2.setString(1, txtID.getText());

		                pst2.execute();
		                JOptionPane.showMessageDialog(null, "Deleted Successfully");

		            } catch (Exception ee) {
		                JOptionPane.showMessageDialog(null, e);
		            }
		    		Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5 = null ; 
					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from products" ; 
						ps5 = (PreparedStatement) con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					} 
			}
			}
		});
		button_1.setBounds(857, 71, 70, 26);
		contentPane.add(button_1);
	}

	protected void Refreshable() {
		// TODO Auto-generated method stub
		
	}
}
