
public class Employees {
	private int Code ; 
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getContact() {
		return Contact;
	}
	public void setContact(int contact) {
		Contact = contact;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getEmployee_Type() {
		return Employee_Type;
	}
	public void setEmployee_Type(String employee_Type) {
		Employee_Type = employee_Type;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public int getBouns() {
		return Bouns;
	}
	public void setBouns(int bouns) {
		Bouns = bouns;
	}
	public String getHire_Date() {
		return Hire_Date;
	}
	public void setHire_Date(String hire_Date) {
		Hire_Date = hire_Date;
	}
	private String Name ; 
	public Employees(int code, String name, String address, int contact, String email, String employee_Type, int salary,
			int bouns, String hire_Date) {
		super();
		Code = code;
		Name = name;
		Address = address;
		Contact = contact;
		Email = email;
		Employee_Type = employee_Type;
		Salary = salary;
		Bouns = bouns;
		Hire_Date = hire_Date;
	}
	private String Address ; 
	private int Contact ; 
	private String Email ; 
	private String Employee_Type ; 
	private int Salary ; 
	private int Bouns ; 
	private String Hire_Date ; 
 
}
