
public class Suppliers {
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getContact() {
		return Contact;
	}
	public void setContact(int contact) {
		Contact = contact;
	}
	public String getProduct_Type() {
		return Product_Type;
	}
	public void setProduct_Type(String product_Type) {
		Product_Type = product_Type;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	private int Code ; 
 	public Suppliers(int code, String name, String address, int contact, String product_Type, String website,
			String email) {
		super();
		Code = code;
		Name = name;
		Address = address;
		Contact = contact;
		Product_Type = product_Type;
		this.website = website;
		Email = email;
	}
	private String Name ; 
	private String Address ; 
	private int Contact ; 
	private String Product_Type ; 
	private String website ; 
	private String Email ; 
}

	
