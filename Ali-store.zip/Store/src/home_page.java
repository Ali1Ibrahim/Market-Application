import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class home_page extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home_page frame = new home_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public home_page() {
		setUndecorated(true);
		setMinimumSize(new Dimension(600, 600));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 550);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				OrdersPage od = new OrdersPage() ; 
				od.setVisible(true);
				setVisible(false);
			}
		});
		label.setIcon(new ImageIcon(home_page.class.getResource("/soursess/shopping-cart (4).png")));
		label.setBounds(299, 260, 134, 136);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(home_page.class.getResource("/soursess/6745995f-be16-40c8-96d9-bc6ffe829dae.png")));
		label_1.setBounds(277, -11, 191, 207);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddEmployee aep = new AddEmployee() ;
				aep.setVisible(true);
				setVisible(false);
			}
		});
		label_2.setIcon(new ImageIcon(home_page.class.getResource("/soursess/employee (2).png")));
		label_2.setBounds(560, 154, 128, 144);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("");
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddProduct adp = new AddProduct(); 
				adp.setVisible(true);
				setVisible(false);
			}
		});
		label_3.setIcon(new ImageIcon(home_page.class.getResource("/soursess/warehouse (2).png")));
		label_3.setBounds(36, 385, 128, 128);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddCustomer adc = new AddCustomer() ;
				adc.setVisible(true);
				setVisible(false);
			}
		});
		label_4.setIcon(new ImageIcon(home_page.class.getResource("/soursess/team.png")));
		label_4.setBounds(36, 168, 140, 151);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("");
		label_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddSupplier ads = new AddSupplier() ; 
				ads.setVisible(true);
				setVisible(false);
			}
		});
		label_5.setIcon(new ImageIcon(home_page.class.getResource("/soursess/hotel-supplier.png")));
		label_5.setBounds(552, 385, 158, 137);
		contentPane.add(label_5);
		
		JLabel lblOrders = new JLabel("Orders");
		lblOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				OrdersPage od = new OrdersPage() ; 
				od.setVisible(true);
				setVisible(false);
			}
		});
		lblOrders.setForeground(Color.BLUE);
		lblOrders.setBackground(Color.WHITE);
		lblOrders.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblOrders.setBounds(329, 406, 93, 23);
		contentPane.add(lblOrders);
		
		JLabel lblCustomers = new JLabel("Customers");
		lblCustomers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddCustomer adc = new AddCustomer() ;
				adc.setVisible(true);
				setVisible(false);
			}
		});
		lblCustomers.setForeground(Color.BLUE);
		lblCustomers.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblCustomers.setBackground(Color.WHITE);
		lblCustomers.setBounds(36, 320, 137, 23);
		contentPane.add(lblCustomers);
		
		JLabel lblEmployees = new JLabel("Employees");
		lblEmployees.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddEmployee aep = new AddEmployee() ;
				aep.setVisible(true);
				setVisible(false);
			}
		});
		lblEmployees.setForeground(Color.BLUE);
		lblEmployees.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblEmployees.setBackground(Color.WHITE);
		lblEmployees.setBounds(560, 309, 134, 23);
		contentPane.add(lblEmployees);
		
		JLabel lblSuppliers = new JLabel("Suppliers");
		lblSuppliers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddSupplier ads = new AddSupplier() ; 
				ads.setVisible(true);
				setVisible(false);
			}
		});
		lblSuppliers.setForeground(Color.BLUE);
		lblSuppliers.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblSuppliers.setBackground(Color.WHITE);
		lblSuppliers.setBounds(576, 527, 112, 23);
		contentPane.add(lblSuppliers);
		
		JLabel lblWarehouse = new JLabel("Warehouse");
		lblWarehouse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AddProduct adp = new AddProduct(); 
				adp.setVisible(true);
				setVisible(false);
			}
		});
		lblWarehouse.setForeground(Color.BLUE);
		lblWarehouse.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblWarehouse.setBackground(Color.WHITE);
		lblWarehouse.setBounds(36, 522, 140, 23);
		contentPane.add(lblWarehouse);
		
		JLabel label_6 = new JLabel("");
		label_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setVisible(false);
			}
		});
		label_6.setIcon(new ImageIcon(home_page.class.getResource("/soursess/stand-by.png")));
		label_6.setBounds(687, 0, 23, 33);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("");
		label_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Login lo = new Login() ; 
				lo.setVisible(true);
				setVisible(false);
			}
		});
		label_7.setIcon(new ImageIcon(home_page.class.getResource("/soursess/reply (2).png")));
		label_7.setBounds(635, 0, 31, 32);
		contentPane.add(label_7);
	}
}
