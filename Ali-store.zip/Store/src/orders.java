import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.HeadlessException;
import java.awt.Toolkit;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;

public class orders extends JFrame {
	
	
	

	 JPanel contentPane;
	 public JTextField tx_code;
	 
	




	  public JTextField tx_quantity;
	  public JTextField tx_price_pcs;
	  public JTextField tx_Total;
	
	  public String Product_id;
	  public String Product_Name;
	  public String Quantity;
	  public String PiecePrice;
	  public String Total;
	  public String Recipt_code;
	  
	  
	  
	public JTable table;
	private JTextField tx_recipt;
	public JTable ProductsTable;
	public JTextField tx_name;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public orders() {
		setResizable(false);
		setTitle("Add Order");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1502, 633);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Toolkit tk = getToolkit();
		Dimension size = tk.getScreenSize();
		setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
		
		tx_name = new JTextField();
		tx_name.setBounds(733, 108, 102, 20);
		contentPane.add(tx_name);
		tx_name.setColumns(10);
		
		JLabel lblProductname = new JLabel("Product_Name:");
		lblProductname.setForeground(Color.DARK_GRAY);
		lblProductname.setFont(new Font("MV Boli", Font.PLAIN, 12));
		lblProductname.setBounds(570, 108, 90, 14);
		contentPane.add(lblProductname);
		
		JLabel lblProductsTable = new JLabel("Products Table");
		lblProductsTable.setFont(new Font("MV Boli", Font.PLAIN, 17));
		lblProductsTable.setForeground(Color.RED);
		lblProductsTable.setBounds(150, 11, 168, 14);
		contentPane.add(lblProductsTable);
		
		JLabel lblOrdersTable = new JLabel("Orders Table");
		lblOrdersTable.setForeground(Color.RED);
		lblOrdersTable.setFont(new Font("MV Boli", Font.PLAIN, 17));
		lblOrdersTable.setBounds(1092, 19, 220, 14);
		contentPane.add(lblOrdersTable);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 41, 558, 562);
		contentPane.add(scrollPane_1);
		
		ProductsTable = new JTable();
		ProductsTable.addMouseMotionListener(new MouseMotionAdapter() {
			 
		});
		scrollPane_1.setViewportView(ProductsTable);
		
		tx_recipt = new JTextField();
		tx_recipt.setBounds(733, 231, 102, 20);
		contentPane.add(tx_recipt);
		tx_recipt.setColumns(10);
		
		JLabel lblReciptcode = new JLabel("Recipt_Code");
		lblReciptcode.setForeground(Color.DARK_GRAY);
		lblReciptcode.setFont(new Font("MV Boli", Font.PLAIN, 12));
		lblReciptcode.setBounds(579, 234, 90, 14);
		contentPane.add(lblReciptcode);
		
		tx_code = new JTextField();
		tx_code.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				
				
				Connection con2 =null;
				PreparedStatement pst2 = null;
				ResultSet rs2 = null;
				try {
					con2=DBconnect.getConnection();
					String query = "SELECT * FROM store.products;";
					pst2=con2.prepareStatement(query);
					rs2=pst2.executeQuery();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		tx_code.setColumns(10);
		tx_code.setBounds(733, 41, 102, 20);
		contentPane.add(tx_code);
		
		tx_quantity = new JTextField();
		tx_quantity.setColumns(10);
		tx_quantity.setBounds(733, 74, 102, 20);
		contentPane.add(tx_quantity);
		
		tx_price_pcs = new JTextField();
		tx_price_pcs.setColumns(10);
		tx_price_pcs.setBounds(733, 148, 102, 20);
		contentPane.add(tx_price_pcs);
		
		tx_Total = new JTextField();
		tx_Total.setColumns(10);
		tx_Total.setBounds(733, 192, 102, 20);
		contentPane.add(tx_Total);
		
		JLabel lblTotal = new JLabel("Total:");
		lblTotal.setForeground(Color.DARK_GRAY);
		lblTotal.setFont(new Font("MV Boli", Font.PLAIN, 13));
		lblTotal.setBounds(579, 195, 90, 14);
		contentPane.add(lblTotal);
		
		JLabel lblPieceprice = new JLabel("PiecePrice:");
		lblPieceprice.setForeground(Color.DARK_GRAY);
		lblPieceprice.setFont(new Font("MV Boli", Font.PLAIN, 13));
		lblPieceprice.setBounds(580, 150, 89, 17);
		contentPane.add(lblPieceprice);
		
		JLabel lblQuantity = new JLabel("Quantity:");
		lblQuantity.setForeground(Color.DARK_GRAY);
		lblQuantity.setFont(new Font("MV Boli", Font.PLAIN, 13));
		lblQuantity.setBounds(579, 73, 111, 22);
		contentPane.add(lblQuantity);
		
		JLabel label_6 = new JLabel("Product_ID:");
		label_6.setForeground(Color.DARK_GRAY);
		label_6.setFont(new Font("MV Boli", Font.PLAIN, 13));
		label_6.setBounds(580, 44, 80, 14);
		contentPane.add(label_6);
		
		JButton button_1 = new JButton("Add");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					 Product_id = tx_code.getText();
					 Product_Name = tx_name.getText();
					 Quantity = tx_quantity.getText();
					 PiecePrice = tx_price_pcs.getText();
					 Total = tx_Total.getText();
					 Recipt_code = tx_recipt.getText();
					 
					 
					 
						
					Connection con =null;
					PreparedStatement pst = null;
					
					String sql="INSERT INTO `store`.`orders` (`Product_ID`, `Product_Name`,`Quantity`, `PiecePrice`, `Total`, `Recipt_code`) VALUES (? , ? , ? , ? , ? , ?);"; 

					con=DBconnect.getConnection();
					pst=con.prepareStatement(sql);
					pst.setString(1,Product_id);
					pst.setString(2,Product_Name);
					pst.setString(3,Quantity);
					pst.setString(4,PiecePrice);
					pst.setString(5,Total);
					pst.setString(6,Recipt_code);


					pst.executeUpdate();
					
					Connection con2 =null;
					PreparedStatement pst2 = null;
					ResultSet rs2 = null;
					try {
						Recipt_code = tx_recipt.getText();
						con2=DBconnect.getConnection();
						String query = "Select * from orders where Receipt_ID = ?";
						pst2=con2.prepareStatement(query);
						pst2.setString(1,Recipt_code);
						rs2=pst2.executeQuery();
						

						table.setModel(DbUtils.resultSetToTableModel(rs2));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					Connection conn = null;

				    try {
				        conn = DBconnect.getConnection();

				        String query = "UPDATE products SET PCS_Remaining = PCS_Remaining - ? WHERE Product_ID = ? and PCS_Remaining > 0";

				        PreparedStatement pstmt = conn.prepareStatement(query);
				        pstmt.setString(1, Quantity);
				        pstmt.setString(2,Product_id);

				        pstmt.executeUpdate();

				    } catch (Exception e) {
				        // If we don't have a error, close the connection!
				        System.err.println("Exception: " + e.getMessage());

				    } finally {
				        try {
				            if (conn != null) {
				                conn.close();
				            }
				        } catch (SQLException e) {

				        }
				    }
					
					
					
					tx_code.setText("");
					tx_quantity.setText("");
					tx_price_pcs.setText("");
					tx_Total.setText("");
					tx_name.setText("");
					
					
					Connection con3 =null;
					PreparedStatement pst3 = null;
					ResultSet rs3 = null;
					try {
						con3=DBconnect.getConnection();
						String query = "Select * from products";
						pst3=con3.prepareStatement(query);
						rs3=pst3.executeQuery();
						ProductsTable.setModel(DbUtils.resultSetToTableModel(rs3));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
									    
					
					 
		
					}
					catch(SQLException  | HeadlessException ex)
					{
						ex.printStackTrace();
					JOptionPane.showMessageDialog(null,"Error In Adding");
					}
				
				
			}
		});
		button_1.setFont(new Font("Arial Black", Font.PLAIN, 13));
		button_1.setBounds(645, 259, 89, 23);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Back");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				setVisible(false);
				
				
			}
		});
		button_2.setFont(new Font("Arial Black", Font.PLAIN, 13));
		button_2.setBounds(641, 501, 108, 23);
		contentPane.add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(845, 44, 641, 559);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnPrintARecipt = new JButton("Print a Recipt");
		btnPrintARecipt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				MessageFormat header = new MessageFormat("Report Print");
				
				MessageFormat footer = new MessageFormat("Page{0,number,integer}");
				
				
				
				Date obj = new Date();
				String date = obj.toString();
				
				
				try {
					table.print(JTable.PrintMode.NORMAL, header , footer);
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					System.err.format("Cannot Print %s%n", e.getMessage());
				}
				
				
				
				    
				    }
			}
		
				    
				
				
					
				    
			
		
			
		);
		btnPrintARecipt.setForeground(Color.RED);
		btnPrintARecipt.setFont(new Font("Arial Black", Font.BOLD, 13));
		btnPrintARecipt.setBounds(616, 305, 145, 23);
		contentPane.add(btnPrintARecipt);
		 
		 
	
	}
}
