import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.security.auth.Refreshable;
import javax.swing.ImageIcon;

public class AddEmployee extends JFrame {

	private JPanel contentPane;
	private JTextField tx_code;
	private JTextField tx_name;
	private JTextField tx_address;
	private JTextField tx_email;
	private JTextField tx_contact;
	private JTextField tx_emptype;
	private JTextField tx_salary;
	private JTextField tx_bouns;
	private JTextField tx_hiredate;
	private JButton btnDisplayTable;
	private JTable table;
	private JLabel label_1;
	private JTextField txtID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddEmployee frame = new AddEmployee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddEmployee() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1011, 606);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Code");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(33, 75, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(33, 113, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Address");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(33, 154, 61, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(33, 236, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Contact");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(33, 192, 61, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Employee Type");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setBounds(21, 280, 96, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Salary");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_6.setBounds(33, 324, 46, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("bouns");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_7.setBounds(33, 366, 46, 14);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Hire_Date");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_8.setBounds(33, 406, 84, 14);
		contentPane.add(lblNewLabel_8);
		
		tx_code = new JTextField();
		tx_code.setBounds(224, 73, 142, 20);
		contentPane.add(tx_code);
		tx_code.setColumns(10);
		
		tx_name = new JTextField();
		tx_name.setBounds(224, 111, 142, 20);
		contentPane.add(tx_name);
		tx_name.setColumns(10);
		
		tx_address = new JTextField();
		tx_address.setBounds(224, 152, 142, 20);
		contentPane.add(tx_address);
		tx_address.setColumns(10);
		
		tx_email = new JTextField();
		tx_email.setBounds(224, 234, 142, 20);
		contentPane.add(tx_email);
		tx_email.setColumns(10);
		
		tx_contact = new JTextField();
		tx_contact.setBounds(224, 190, 142, 20);
		contentPane.add(tx_contact);
		tx_contact.setColumns(10);
		
		tx_emptype = new JTextField();
		tx_emptype.setBounds(224, 278, 142, 20);
		contentPane.add(tx_emptype);
		tx_emptype.setColumns(10);
		
		tx_salary = new JTextField();
		tx_salary.setBounds(224, 322, 142, 20);
		contentPane.add(tx_salary);
		tx_salary.setColumns(10);
		
		tx_bouns = new JTextField();
		tx_bouns.setBounds(224, 364, 142, 20);
		contentPane.add(tx_bouns);
		tx_bouns.setColumns(10);
		
		tx_hiredate = new JTextField();
		tx_hiredate.setBounds(224, 404, 142, 20);
		contentPane.add(tx_hiredate);
		tx_hiredate.setColumns(10);
		
		JButton btnAddEmployee = new JButton("Add Employee");
		btnAddEmployee.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAddEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String email = tx_email.getText(); 
			    String contact = tx_contact.getText();

			    String employee_type = tx_emptype.getText();
			    String salary= tx_salary.getText(); 
			    String bouns = tx_bouns.getText();
			    String hire_date = tx_hiredate.getText();

			     try {
			            Connection con = DBconnect.getConnection(); 
			            
			          String query =  "INSERT INTO `store`.`employees` (`Code`, `Name`, `Address`, `Contact`, `Email`, `Employee_Type`, `Salary`, `Bouns`, `Hire_Date`) VALUES (?, ?, ?,?,?,?,?,?,?);" ;
			             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query); 
			            ps.setString(1, id);
			            ps.setString(2, name);
			            ps.setString(3, address);
			            ps.setString(4, email);
			            ps.setString(5, contact);
			            ps.setString(6, employee_type);
			            ps.setString(7,salary);
			            ps.setString(8, bouns);
			            ps.setString(9, hire_date);

			            ps.executeUpdate() ;

			             JOptionPane.showMessageDialog(null, "successful");
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

			           e.printStackTrace();
			        }
			 	Connection con2 = null ; 
				PreparedStatement ps2 = null ; 
				ResultSet rs2 = null ; 
				try {
					con2=DBconnect.getConnection() ; 
					String query = "Select * from employees" ; 
					ps2 = con2.prepareStatement(query);
					rs2=ps2.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs2)) ;
					
				} catch (SQLException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				} 
			     
			}
		});
		btnAddEmployee.setBounds(224, 490, 151, 23);
		contentPane.add(btnAddEmployee);
		
		btnDisplayTable = new JButton("Display Table");
		btnDisplayTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Connection con10 = null ; 
				PreparedStatement ps5 = null ; 
				ResultSet rs5= null ; 
				try {
					con10=DBconnect.getConnection() ; 
					String query = "Select * from employees" ; 
					ps5 = con10.prepareStatement(query);
					rs5=ps5.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
					
				} catch (SQLException e) {
		             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
				try {
					con10=DBconnect.getConnection() ; 
					String query = "Select * from employees" ; 
					ps5 = con10.prepareStatement(query);
					rs5=ps5.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
					
				} catch (SQLException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				} 
				  
			}
		});
		btnDisplayTable.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDisplayTable.setBounds(224, 524, 151, 23);
		contentPane.add(btnDisplayTable);
		
		JLabel lblAddEmployees = new JLabel("Employees");
		lblAddEmployees.setForeground(Color.ORANGE);
		lblAddEmployees.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAddEmployees.setBounds(251, 11, 115, 33);
		contentPane.add(lblAddEmployees);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(371, 75, 634, 345);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
			}
		});
		label.setIcon(new ImageIcon(AddEmployee.class.getResource("/soursess/stand-by.png")));
		label.setBounds(978, 11, 23, 25);
		contentPane.add(label);
		
		label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				home_page hp = new home_page();
				hp.setVisible(true);
				setVisible(false);
			}
		});
		label_1.setIcon(new ImageIcon(AddEmployee.class.getResource("/soursess/reply (2).png")));
		label_1.setBounds(945, 11, 23, 25);
		contentPane.add(label_1);
		
		JButton button = new JButton("Modify - Edit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String contact = tx_contact.getText();
			    String email = tx_email.getText(); 
			    String emptype = tx_emptype.getText();
			    String salary = tx_salary.getText(); 
			    String bouns = tx_bouns.getText();
			    String hire_date = tx_hiredate.getText();

			     try {
			            Connection con = DBconnect.getConnection(); 
			            
			          String query = "UPDATE `store`.`employees` SET `Name` = ?, `Address` = ?, `Contact` = ?, `Email` = ?, `Employee_Type` = ?, `Salary` = ?, `Bouns` = ?, `Hire_Date` = ? WHERE (`Code` = ?);";


			             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query); 
			            ps.setString(1, name);
			            ps.setString(2, address);
			            ps.setString(3, contact);
			            ps.setString(4, email);
			            ps.setString(5, emptype);
			            ps.setString(6,salary);
			            ps.setString(7, bouns);
			            ps.setString(8, hire_date);
			            ps.setString(9, id);


			            ps.executeUpdate() ;
						Refreshable();


			             JOptionPane.showMessageDialog(null, "successful");
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

			           e.printStackTrace();
			        }
			
					Refreshable();
					Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5= null ; 
					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from employees" ; 
						ps5 = con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 
					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from employees" ; 
						ps5 = con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					} 

			}

			private void Refreshable() {
				// TODO Auto-generated method stub
				
			}
			
		});
		button.addMouseListener(new MouseAdapter() {
			 
		 
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 15));
		button.setBounds(224, 558, 151, 23);
		contentPane.add(button);
		
		txtID = new JTextField();
		txtID.setToolTipText("ID");
		txtID.setText(" ");
		txtID.setColumns(10);
		txtID.setBounds(826, 47, 86, 25);
		contentPane.add(txtID);
		
		JButton button_1 = new JButton("Delete");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		int message = JOptionPane.showConfirmDialog(null, "Do you Want Delete ?", "Delete", JOptionPane.YES_NO_OPTION);
				

		        if (message == 0) {

		            try {
		            	Connection con2 = null;
		            	PreparedStatement pst2 = null;
		            	con2 = DBconnect.getConnection();
		            	
		                String sql = " delete from employees where Code = ?";
                        pst2 = con2.prepareStatement(sql);
                        
		               
		                pst2.setString(1, txtID.getText());

		                pst2.execute();
		                JOptionPane.showMessageDialog(null, "Deleted Successfully");

		            } catch (Exception ee) {
		                JOptionPane.showMessageDialog(null, e);
		            }
		    		Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5 = null ; 
					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from employees" ; 
						ps5 = con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					} 

		        }
			}
		});
		button_1.setBounds(922, 47, 70, 26);
		contentPane.add(button_1);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i = table.getSelectedRow();
				 int id = Integer.parseInt(table.getValueAt(i, 0).toString());
				 String name = table.getValueAt(i, 1).toString();
				 String Address = table.getValueAt(i, 2).toString();
				 String Contact = table.getValueAt(i, 3).toString();

				 String Email = table.getValueAt(i, 4).toString();

				 String emptype = table.getValueAt(i, 5).toString();

              
				 String Salary = table.getValueAt(i, 6).toString();
				 String bouns = table.getValueAt(i, 7).toString();
				 String hire_date = table.getValueAt(i, 8).toString();


				 tx_code.setText(""+id);
				 tx_name.setText(name);
				 tx_address.setText(Address);
				 tx_contact.setText(Contact);

				 tx_email.setText(Email);
				 tx_emptype.setText(emptype);


				 tx_salary.setText(Salary);
				 tx_bouns.setText(bouns);
				 tx_hiredate.setText(hire_date);
			}
		});
	}
}
