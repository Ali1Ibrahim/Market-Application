import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;

public class DBconnect {
public static synchronized Connection getConnection() {
	
	Connection con = null ; 
	try {
		Class.forName("com.mysql.jdbc.Driver") ; 
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/store","root","1234") ;
 	} catch (ClassNotFoundException e) {
		JOptionPane.showMessageDialog(null, "connection Erorr");

 		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	return con ; 
	
}
public static synchronized PreparedStatement pst(String sql) {
	PreparedStatement ps = null ; 
    String query = "" ; 
	try {
		ps.executeQuery();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
    
	
	
	
	return ps ; 
}

}
