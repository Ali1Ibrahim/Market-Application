
public class Products {
	private int Code ; 
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getDesc() {
		return Desc;
	}
	public void setDesc(String desc) {
		Desc = desc;
	}
	public String getColor() {
		return Color;
	}
	public void setColor(String color) {
		Color = color;
	}
	public int getPCSinCTN() {
		return PCSinCTN;
	}
	public void setPCSinCTN(int pCSinCTN) {
		PCSinCTN = pCSinCTN;
	}
	public int getT_CIN() {
		return T_CIN;
	}
	public void setT_CIN(int t_CIN) {
		T_CIN = t_CIN;
	}
	public int getT_PCS() {
		return T_PCS;
	}
	public void setT_PCS(int t_PCS) {
		T_PCS = t_PCS;
	}
	public int getPrice_Pcs() {
		return Price_Pcs;
	}
	public void setPrice_Pcs(int price_Pcs) {
		Price_Pcs = price_Pcs;
	}
	public int getCartoon_price() {
		return Cartoon_price;
	}
	public void setCartoon_price(int cartoon_price) {
		Cartoon_price = cartoon_price;
	}
	private String Name ; 
	public Products(int code, String name, String type, String desc, String color, int pCSinCTN, int t_CIN, int t_PCS,
			int price_Pcs, int cartoon_price) {
		super();
		Code = code;
		Name = name;
		Type = type;
		Desc = desc;
		Color = color;
		PCSinCTN = pCSinCTN;
		T_CIN = t_CIN;
		T_PCS = t_PCS;
		Price_Pcs = price_Pcs;
		Cartoon_price = cartoon_price;
	}
	private String Type ; 
	private String Desc ; 
	private String Color ; 
	private int PCSinCTN ; 
	private int T_CIN ; 
	private int T_PCS ; 
	private int Price_Pcs ; 
	private int Cartoon_price ;
}
