import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.naming.spi.DirStateFactory.Result;
import javax.security.auth.Refreshable;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AddCustomer extends JFrame {

	private JPanel contentPane;
	private JTextField tx_code;
	private JTextField tx_name;
	private JTextField tx_address;
	private JTextField tx_mobile;
	private JTextField tx_email;
	private JTextField tx_rank;
	private JTextField tx_start_date;
	private JTextField tx_total_spent;
	private JTextField txtID;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddCustomer frame = new AddCustomer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddCustomer() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 496);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(21, 11, 46, 14);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("Code");
		lblNewLabel.setBounds(21, 94, 57, 14);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(21, 132, 57, 14);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Address");
		lblNewLabel_2.setBounds(21, 170, 68, 14);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Mobile");
		lblNewLabel_3.setBounds(21, 208, 57, 14);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Email");
		lblNewLabel_4.setBounds(21, 246, 57, 14);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel(" Rank");
		lblNewLabel_5.setBounds(21, 284, 57, 14);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Start Date");
		lblNewLabel_6.setBounds(21, 322, 78, 14);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Total Spent");
		lblNewLabel_7.setBounds(21, 359, 78, 14);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_7);
		
		tx_code = new JTextField();
		tx_code.setBounds(143, 89, 214, 27);
		contentPane.add(tx_code);
		tx_code.setColumns(10);
		
		tx_name = new JTextField();
		tx_name.setBounds(143, 127, 214, 27);
		contentPane.add(tx_name);
		tx_name.setColumns(10);
		
		tx_address = new JTextField();
		tx_address.setBounds(143, 165, 214, 27);
		contentPane.add(tx_address);
		tx_address.setColumns(10);
		
		tx_mobile = new JTextField();
		tx_mobile.setBounds(143, 203, 214, 27);
		contentPane.add(tx_mobile);
		tx_mobile.setColumns(10);
		
		tx_email = new JTextField();
		tx_email.setBounds(143, 241, 214, 27);
		contentPane.add(tx_email);
		tx_email.setColumns(10);
		
		tx_rank = new JTextField();
		tx_rank.setBounds(143, 279, 214, 27);
		contentPane.add(tx_rank);
		tx_rank.setColumns(10);
		
		tx_start_date = new JTextField();
		tx_start_date.setBounds(143, 317, 214, 27);
		contentPane.add(tx_start_date);
		tx_start_date.setColumns(10);
		
		tx_total_spent = new JTextField();
		tx_total_spent.setBounds(143, 355, 214, 25);
		contentPane.add(tx_total_spent);
		tx_total_spent.setColumns(10);
		
		JButton btnAddCustomer = new JButton("Add Customer");
		btnAddCustomer.setBounds(161, 405, 154, 23);
		btnAddCustomer.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnAddCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String mobile = tx_mobile.getText();
			    String email = tx_email.getText(); 
			    String rank = tx_rank.getText();
			    String start_date = tx_start_date.getText(); 
			    String total_spent = tx_total_spent.getText();
			     try {
			            Connection con = DBconnect.getConnection(); 
			            
			          String query =  "INSERT INTO `store`.`customers` (`Code`, `Name`, `Address`, `Mobile`, `Email`, `Rank`, `Start_Date`, `Total_spent`) VALUES (?, ?,?, ?, ?,?, ?,?);"  ;
			             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query); 
			            ps.setString(1, id);
			            ps.setString(2, name);
			            ps.setString(3, address);
			            ps.setString(4, mobile);
			            ps.setString(5, email);
			            ps.setString(6, rank);
			            ps.setString(7,start_date);
			            ps.setString(8, total_spent);
			            ps.executeUpdate() ;

			             JOptionPane.showMessageDialog(null, "Successful");
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong Type , Please try again");

			           e.printStackTrace();
			        }
			    	Connection con10 = null ; 
					PreparedStatement ps5 = null ; 
					ResultSet rs5= null ; 

					try {
						con10=DBconnect.getConnection() ; 
						String query = "Select * from customers" ; 
						ps5 = (PreparedStatement) con10.prepareStatement(query);
						rs5=ps5.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
						
					} catch (SQLException ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					}
			    
			    
			}
		});
		contentPane.add(btnAddCustomer);
		
		JLabel lblCustomers = new JLabel("Customers");
		lblCustomers.setBounds(220, 11, 163, 25);
		lblCustomers.setForeground(new Color(0, 0, 128));
		lblCustomers.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(lblCustomers);
		
		JButton btnNewButton = new JButton("Display Table");
		btnNewButton.setBounds(161, 439, 154, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 
 				Connection con2 = null ; 
				PreparedStatement ps2 = null ; 
				ResultSet rs2 = null ; 
				try {
					con2=DBconnect.getConnection() ; 
					String query = "Select * from customers" ; 
					ps2 = con2.prepareStatement(query);
					rs2=ps2.executeQuery() ;
				   
					table.setModel(DbUtils.resultSetToTableModel(rs2)) ;
					
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, "Error");
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
			}
			 
			 
	
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		contentPane.add(btnNewButton);
		
		txtID = new JTextField();
		txtID.setBounds(725, 48, 86, 20);
		txtID.setToolTipText("ID");
		txtID.setText(" ");
		txtID.setColumns(10);
		contentPane.add(txtID);
		
		JButton button_1 = new JButton("Delete");
		button_1.setBounds(821, 48, 70, 21);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int message = JOptionPane.showConfirmDialog(null, "Do you Want Delete ?", "Delete", JOptionPane.YES_NO_OPTION);
				

		        if (message == 0) {

		            try {
		            	Connection con2 = null;
		            	PreparedStatement pst2 = null;
		            	con2 = DBconnect.getConnection();
		            	
		                String sql = " delete from customers where Code = ?";
                        pst2 = con2.prepareStatement(sql);
                        
		               
		                pst2.setString(1, txtID.getText());

		                pst2.execute();
		                JOptionPane.showMessageDialog(null, "Deleted Successfully");

		            } catch (Exception e) {

 		                JOptionPane.showMessageDialog(null, "worng type , try again");

		            }
		    		Connection con2 = null ; 
					PreparedStatement ps2 = null ; 
					ResultSet rs2 = null ; 
					try {
						con2=DBconnect.getConnection() ; 
						String query = "Select * from customers" ; 
						ps2 = con2.prepareStatement(query);
						rs2=ps2.executeQuery() ;
					   
						table.setModel(DbUtils.resultSetToTableModel(rs2)) ;
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 

		        } 
			}
		});
		contentPane.add(button_1);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(858, 0, 23, 25);
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setVisible(false);
			}
			
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(361, 89, 530, 291);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
		
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i = table.getSelectedRow();
				 int id = Integer.parseInt(table.getValueAt(i, 0).toString());
				 String name = table.getValueAt(i, 1).toString();
				 String Address = table.getValueAt(i, 2).toString();
				 String Mobile = table.getValueAt(i, 3).toString();
				 String Email = table.getValueAt(i, 4).toString();

 				 String Rank = table.getValueAt(i, 5).toString();
				 String start_date = table.getValueAt(i, 6).toString();
				 String total_spent = table.getValueAt(i, 7).toString();


				 tx_code.setText(""+id);
				 tx_name.setText(name);
				 tx_address.setText(Address);
				 tx_mobile.setText(Mobile);
				 tx_email.setText(Email);
				 tx_rank.setText(Rank);
				 tx_start_date.setText(start_date);
				 tx_total_spent.setText(total_spent);

				
				
			}
		});
		label_1.setIcon(new ImageIcon(AddCustomer.class.getResource("/soursess/stand-by.png")));
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(825, 0, 23, 25);
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				home_page hp = new home_page();
				hp.setVisible(true);
				setVisible(false);
			}
		});
		label_2.setIcon(new ImageIcon(AddCustomer.class.getResource("/soursess/reply (2).png")));
		contentPane.add(label_2);
		
		JButton btnModifyEdit = new JButton("Modify - Edit");
		btnModifyEdit.setBounds(161, 473, 154, 23);
		btnModifyEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = tx_code.getText(); 
			    String name = tx_name.getText();
			    String address = tx_address.getText(); 
			    String mobile = tx_mobile.getText();
			    String email = tx_email.getText(); 
			    String rank = tx_rank.getText();
			    String start_date = tx_start_date.getText(); 
			    String total_spent = tx_total_spent.getText();
			     try {
			            Connection con = DBconnect.getConnection(); 
			            
			          String query =" UPDATE `store`.`customers` SET   `Name` = ?, `Address` = ?, `Mobile` = ?, `Email` = ?, `Rank` = ?, `Start_Date` =?, `Total_spent` = ? WHERE (`Code` = ?);";


			             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
			            ps=con.prepareStatement(query); 
 			            ps.setString(1, name);
			            ps.setString(2, address);
			            ps.setString(3, mobile);
			            ps.setString(4, email);
			            ps.setString(5, rank);
			            ps.setString(6,start_date);
			            ps.setString(7, total_spent);
			            ps.setString(8, id);

			            ps.executeUpdate() ;
			            

			             JOptionPane.showMessageDialog(null, "Successful");
			     		Connection con10 = null ; 
						PreparedStatement ps5 = null ; 
						ResultSet rs5= null ; 
						try {
							con10=DBconnect.getConnection() ; 
							String query2 = "Select * from customers" ; 
							ps5 = con10.prepareStatement(query2);
							rs5=ps5.executeQuery() ;
						   
							table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
							
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 
						try {
							con10=DBconnect.getConnection() ; 
							String query2 = "Select * from customers" ; 
							ps5 = con10.prepareStatement(query2);
							rs5=ps5.executeQuery() ;
						   
							table.setModel(DbUtils.resultSetToTableModel(rs5)) ;
							
						} catch (SQLException ee) {
							// TODO Auto-generated catch block
							ee.printStackTrace();
						}
			        } catch (Exception e) {
			             JOptionPane.showMessageDialog(null, "Wrong type , Please try again");

			           e.printStackTrace();

			        }
			     Refreshable();
			     
 
			    
			
			}
			private void Refreshable() {
				// TODO Auto-generated method stub
				
			}

			 
		});
		btnModifyEdit.setFont(new Font("Tahoma", Font.BOLD, 15));
		contentPane.add(btnModifyEdit);
	}

	protected void Refreshable() {
		// TODO Auto-generated method stub
		
	}
}
