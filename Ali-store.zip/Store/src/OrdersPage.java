import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.awt.Font;

public class OrdersPage extends JFrame {

	private JPanel contentPane;
	private JTextField tx_id;
	private JTextField tx_Quantity;
	private JTextField tx_Name;
	private JTextField tx_pieceprice;
	private JTextField tx_Total;
	private JTextField tx_recipt;
	private JTable table;
	  public String Product_id;
	  public String Product_Name;
	  public String Quantity;
	  public String PiecePrice;
	  public String Total;
	  public String Recipt_code;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrdersPage frame = new OrdersPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OrdersPage() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 782, 535);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblProductid = new JLabel("Product_ID");
		lblProductid.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblProductid.setBounds(10, 48, 88, 14);
		contentPane.add(lblProductid);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblQuantity.setBounds(10, 90, 68, 14);
		contentPane.add(lblQuantity);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblName.setBounds(10, 123, 88, 14);
		contentPane.add(lblName);
		
		JLabel lblPiecePrice = new JLabel("Piece Price");
		lblPiecePrice.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPiecePrice.setBounds(10, 154, 88, 14);
		contentPane.add(lblPiecePrice);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTotal.setBounds(10, 193, 88, 14);
		contentPane.add(lblTotal);
		
		JLabel lblReciptid = new JLabel("Recipt_ID");
		lblReciptid.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblReciptid.setBounds(10, 224, 88, 14);
		contentPane.add(lblReciptid);
		
		tx_id = new JTextField();
		tx_id.addKeyListener(new KeyAdapter() {
			 
		 
			 
			public void keyReleased(KeyEvent arg0) {
				Connection con3 =null;
				PreparedStatement pst3 = null;
				
				try {

		            String sql3 = " select * from products where code =?";

		            con3=DBconnect.getConnection();
					pst3=con3.prepareStatement(sql3);
		            pst3.setString(1, tx_id.getText());

		            ResultSet rs = pst3.executeQuery();


		            if (rs.next()) {

		                String add2 = rs.getString("Name");
		                tx_Name.setText(add2);
		                String add9 = rs.getString("psprice");
		                tx_pieceprice.setText(add9);
		                

		            }

		        } catch (SQLException e) {
		            JOptionPane.showMessageDialog(null, e);
		        }
			}
		});
		tx_id.setBounds(108, 45, 125, 20);
		contentPane.add(tx_id);
		tx_id.setColumns(10);
		
		tx_Quantity = new JTextField();
		tx_Quantity.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {

			}
			@Override
			public void keyReleased(KeyEvent arg0) {

				Double num1 = Double.parseDouble(tx_pieceprice.getText());
		        Double  qty = Double.parseDouble(tx_Quantity.getText());
		        Double  qty1 = num1 * qty;
		        tx_Total.setText("" + qty1);
			}
		});
		tx_Quantity.setBounds(108, 87, 125, 20);
		contentPane.add(tx_Quantity);
		tx_Quantity.setColumns(10);
		
		tx_Name = new JTextField();
		tx_Name.setBounds(108, 120, 125, 20);
		contentPane.add(tx_Name);
		tx_Name.setColumns(10);
		
		tx_pieceprice = new JTextField();
		tx_pieceprice.setBounds(108, 151, 125, 20);
		contentPane.add(tx_pieceprice);
		tx_pieceprice.setColumns(10);
		
		tx_Total = new JTextField();
		tx_Total.setBounds(108, 190, 125, 20);
		contentPane.add(tx_Total);
		tx_Total.setColumns(10);
		
		tx_recipt = new JTextField();
		tx_recipt.setBounds(108, 221, 125, 20);
		contentPane.add(tx_recipt);
		tx_recipt.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) { 

				try{
					 Product_id = tx_id.getText();
					 Product_Name = tx_Name.getText();
					 Quantity = tx_Quantity.getText();
					 PiecePrice = tx_pieceprice.getText();
					 Total = tx_Total.getText();
					 Recipt_code = tx_recipt.getText();
					 
					 
					 
						
					Connection con =null;
					PreparedStatement pst = null;
					
					String sql= "INSERT INTO `store`.`orders` (`code`, `Name`, `Quantity`, `PiecePrice`, `Total`, `Receipt_ID`) VALUES (?,?, ?, ?, ?, ?);";
					

					con=DBconnect.getConnection();
					pst=con.prepareStatement(sql);
					pst.setString(1,Product_id);
					pst.setString(2,Product_Name);
					pst.setString(3,Quantity);
					pst.setString(4,PiecePrice);
					pst.setString(5,Total);
					pst.setString(6,Recipt_code);


					pst.executeUpdate();
					
					Connection con2 =null;
					PreparedStatement pst2 = null;
					ResultSet rs2 = null;
					try {
						Recipt_code = tx_recipt.getText();
						con2=DBconnect.getConnection();
						String query = "Select * from orders where Receipt_ID = ?";
						pst2=con2.prepareStatement(query);
						pst2.setString(1,Recipt_code);
						rs2=pst2.executeQuery();
						

						table.setModel(DbUtils.resultSetToTableModel(rs2));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					Connection conn = null;

				    try {
				        conn = DBconnect.getConnection();

				        String query = "UPDATE products SET PCS_Remaining = PCS_Remaining - ? WHERE Product_ID = ? and PCS_Remaining > 0";

				        PreparedStatement pstmt = conn.prepareStatement(query);
				        pstmt.setString(1, Quantity);
				        pstmt.setString(2,Product_id);

				        pstmt.executeUpdate();

				    } catch (Exception e) {
				        // If we don't have a error, close the connection!
				        System.err.println("Exception: " + e.getMessage());

				    } finally {
				        try {
				            if (conn != null) {
				                conn.close();
				            }
				        } catch (SQLException e) {

				        }
				    }
				
		
					}
					catch(SQLException  | HeadlessException ex)
					{
						ex.printStackTrace();
					JOptionPane.showMessageDialog(null,"Error In Adding");
					}
				
			}
		});
		btnAdd.setBounds(92, 313, 141, 25);
		contentPane.add(btnAdd);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setForeground(Color.BLUE);
		btnPrint.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				MessageFormat header = new MessageFormat("Print Recipt");
				
				MessageFormat footer = new MessageFormat("Page{0,number,integer}");
				
				
				try {
					table.print(JTable.PrintMode.NORMAL, header , footer);
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					System.err.format("Cannot Print %s%n", e.getMessage());
				}
			}
		});
		btnPrint.setBounds(92, 355, 141, 25);
		contentPane.add(btnPrint);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(243, 47, 529, 194);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setVisible(false);
			}
		});
		label.setIcon(new ImageIcon(OrdersPage.class.getResource("/soursess/stand-by.png")));
		label.setBounds(744, 11, 28, 25);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				home_page hp = new home_page();
				hp.setVisible(true);
				setVisible(false);
			}
		});
		label_1.setIcon(new ImageIcon(OrdersPage.class.getResource("/soursess/reply (2).png")));
		label_1.setBounds(711, 11, 23, 25);
		contentPane.add(label_1);
	}
}
