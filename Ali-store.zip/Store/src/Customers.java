
public class Customers {
	private int Code ; 
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getMobile() {
		return Mobile;
	}
	public void setMobile(int mobile) {
		Mobile = mobile;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getRank() {
		return Rank;
	}
	public void setRank(String rank) {
		Rank = rank;
	}
	public String getStart_Date() {
		return Start_Date;
	}
	public void setStart_Date(String start_Date) {
		Start_Date = start_Date;
	}
	public int getTotal_Spent() {
		return Total_Spent;
	}
	public void setTotal_Spent(int total_Spent) {
		Total_Spent = total_Spent;
	}
	public Customers(int code, String name, String address, int mobile, String email, String rank, String start_Date,
			int total_Spent) {
		super();
		Code = code;
		Name = name;
		Address = address;
		Mobile = mobile;
		Email = email;
		Rank = rank;
		Start_Date = start_Date;
		Total_Spent = total_Spent;
	}
	private String Name ; 
	private String Address ; 
	private int Mobile ; 
	private String Email ; 
	private String Rank ; 
	private String Start_Date ;
	private int Total_Spent ; 


}
