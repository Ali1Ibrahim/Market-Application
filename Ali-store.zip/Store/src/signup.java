import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Font;
import java.awt.Button;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class signup extends JFrame {

	private JPanel contentPane;
	private JTextField tx_id;
	private JTextField tx_email;
	private JPasswordField tx_password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 420);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(433, 63, 71, 14);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(new Color(0, 0, 128));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setBounds(433, 138, 71, 14);
		lblNewLabel_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(433, 222, 71, 14);
		lblNewLabel_2.setForeground(new Color(0, 0, 128));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		contentPane.add(lblNewLabel_2);
		
		tx_id = new JTextField();
		tx_id.setBounds(433, 88, 202, 26);
		contentPane.add(tx_id);
		tx_id.setColumns(10);
		
		tx_email = new JTextField();
		tx_email.setBounds(433, 170, 202, 26);
		contentPane.add(tx_email);
		tx_email.setColumns(10);
		
		tx_password = new JPasswordField();
		tx_password.setBounds(433, 252, 202, 26);
		contentPane.add(tx_password);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(462, 125, 124, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(462, 207, 124, 2);
		contentPane.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(462, 289, 124, 2);
		contentPane.add(separator_2);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 356, 420);
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(81, 95, 200, 176);
		lblNewLabel_3.setIcon(new ImageIcon(signup.class.getResource("/soursess/6745995f-be16-40c8-96d9-bc6ffe829dae.png")));
		panel.add(lblNewLabel_3);
		
		Button btnSignUp = new Button("Sign Up");
		btnSignUp.setBounds(433, 314, 202, 32);
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String id1 = tx_id.getText() ; 
				 String em = tx_email.getText() ; 
				 String pass = tx_password.getText() ; 
				  try {
				      Connection con = DBconnect.getConnection() ; 
				      String query = "INSERT INTO `store`.`login` (`id`, `Email`, `Password`) VALUES ('"+id1+"','"+em+"', '"+pass+"');" ; 

				       java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
				       ps.executeUpdate(); 
				      
				      JOptionPane.showMessageDialog(null, "Congratulation");
				      Login lo = new Login() ; 
				      lo.setVisible(true);
				      setVisible(false);
				 } catch (Exception e) {
				    e.printStackTrace();
				                 JOptionPane.showMessageDialog(null, "Error 404");

				 } 

			}
		});
		btnSignUp.setFont(new Font("Dialog", Font.BOLD, 16));
		btnSignUp.setForeground(Color.WHITE);
		btnSignUp.setBackground(new Color(241,57,83));
		contentPane.add(btnSignUp);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Login lo = new Login(); 
				lo.setVisible(true);
				setVisible(false);
			}
			
		});
		label.setIcon(new ImageIcon(signup.class.getResource("/soursess/reply (2).png")));
		label.setBounds(693, 0, 27, 32);
		contentPane.add(label);
	}
}
 