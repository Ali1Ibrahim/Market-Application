import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Dimension;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.awt.Button;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField tx_email;
	private JPasswordField tx_password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setUndecorated(true);
		setResizable(false);
		setBackground(Color.LIGHT_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 468);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(456, 97, 126, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(456, 207, 113, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblDontHaveAccount = new JLabel("Don't have Account ? ");
		lblDontHaveAccount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDontHaveAccount.setBounds(434, 438, 176, 14);
		contentPane.add(lblDontHaveAccount);
		
		JLabel lblSignUp = new JLabel("Sign Up");
		lblSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				signup sgnp = new signup() ; 
				setVisible(false);
				sgnp.setVisible(true);
				
			}
		});
		lblSignUp.setFont(new Font("Tw Cen MT Condensed", Font.BOLD, 18));
		lblSignUp.setForeground(new Color(0, 0, 128));
		lblSignUp.setBounds(620, 439, 58, 14);
		contentPane.add(lblSignUp);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 355, 495);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Login.class.getResource("/soursess/6745995f-be16-40c8-96d9-bc6ffe829dae.png")));
		label.setBounds(87, 127, 205, 200);
		panel.add(label);
		
		tx_email = new JTextField();
		tx_email.setColumns(10);
		tx_email.setBounds(456, 128, 202, 26);
		contentPane.add(tx_email);
		
		Button button = new Button("Sign In");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String Email = tx_email.getText() ; 
		         String pass = tx_password.getText() ;
		         
		         try {
		            Connection con = DBconnect.getConnection(); 
		            
		          String query = "select * from login where Email = '"+Email+"' and Password = '"+pass+"' " ;
		             java.sql.PreparedStatement ps = con.prepareStatement(query) ; 
		             ResultSet rs = ps.executeQuery(); 
		             if (rs.next()) {
		                              JOptionPane.showMessageDialog(null, "it's correct");
		                              home_page hp = new home_page() ; 
		                              setVisible(false);

		                              hp.setVisible(true);
		                              
		                              

		             }else{
		                         JOptionPane.showMessageDialog(null, "that is not correct");

		             }
		        } catch (Exception e) {
		           e.printStackTrace();
		        } 
		        
			}
		});
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Dialog", Font.BOLD, 16));
		button.setBackground(new Color(241, 57, 83));
		button.setBounds(456, 315, 202, 32);
		contentPane.add(button);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(486, 165, 124, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(486, 276, 124, 2);
		contentPane.add(separator_1);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
			}
		});
		label_1.setIcon(new ImageIcon(Login.class.getResource("/soursess/stand-by.png")));
		label_1.setBounds(699, 0, 31, 32);
		contentPane.add(label_1);
		
		tx_password = new JPasswordField();
		tx_password.setBounds(456, 239, 202, 26);
		contentPane.add(tx_password);
	}
}

