
public class main {

	public static void main(String[] args) {
		DBconnect b = new DBconnect() ;
	    b.getConnection() ; 
		Login lo = new Login() ;
		lo.setVisible(true);
		
	}

}